import { StyleSheet } from "react-native";

export default StyleSheet.create({
  container: {
    paddingHorizontal: 35,
    marginTop: -30,
    flex: 1,
  },
});
