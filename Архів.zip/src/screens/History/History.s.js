import { StyleSheet } from "react-native";

export default StyleSheet.create({
  container: {},
  scroll: {
    // paddingHorizontal: 30,
    paddingTop: 10,
  },
});
