// eslint-disable-next-line import/prefer-default-export
export const appColors = {
  text: "#455A64",
  anotherText: "#334669",
  orange: "rgb(254, 128, 95)",
  blue: "#1877F2",
  lightPurple: "#E9E9FF",
  purple: "#4643D2",
  darkBlue: "#696897",
  lightGray: "#334669",
  anotherPurple: "#A7A9BE",
  red: "#f26d6d",
};
